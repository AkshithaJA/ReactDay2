import React from 'react'

export default function Count({count}) {
  return (
    <div>{count}</div>
  )
}
