import React, { useState } from 'react';
import Navigation from "./Navigation";
import Header from "./Header";
import Section from "./Section";
import Footer from "./Footer";
import Count from "./Count";
import Button from "./Button";

const App = () => {
    const [count, setCount] = useState(0);
	const handleClick = () => {
		setCount(count + 1);
	};
    return (
        <div>
            <Navigation />
            <Header />
            <Section />
            <Footer />
            <Count count = {count} />
            <Button handleClick = {handleClick} />
        </div>
    );
};

export default App;